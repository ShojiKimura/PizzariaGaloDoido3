docker --version
hostname

docker run -d `
--name meu-postgres `
-e POSTGRES_USER=aluno `
-e POSTGRES_PASSWORD=102030 `
-e POSTGRES_DB=db_profedu `
-p 5432:5432 `
postgres:latest

npm install pg